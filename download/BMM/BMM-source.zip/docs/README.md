# Documentation Table of Contents
bear148

### Installation Help Pages
- [Minecraft Command Docs](./Minecraft.md)

### Mod Manager specifics
* ext folder purpose:
   * The use of this folder is for the installation of .zip files. The .zip is extracted to this folder where it is then sorted through to find the correct files needed for the installation of whatever game the mods are being installed for.